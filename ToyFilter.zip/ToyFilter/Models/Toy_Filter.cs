namespace ToyFilter.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Toy_Filter
    {
        [Key]
        [StringLength(5)]
        public string Toy_Id { get; set; }

        [StringLength(40)]
        public string Toy_Name { get; set; }

        [StringLength(200)]
        public string Remarks { get; set; }

        public DateTime? Till_Date { get; set; }
    }
}
