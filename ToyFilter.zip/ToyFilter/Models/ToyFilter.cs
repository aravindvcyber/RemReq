namespace ToyFilter.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ToyFilter : DbContext
    {
        public ToyFilter()
            : base("name=ToyFilter")
        {
        }

        public virtual DbSet<Toy_Filter> Toy_Filter { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Toy_Filter>()
                .Property(e => e.Toy_Id)
                .IsUnicode(false);

            modelBuilder.Entity<Toy_Filter>()
                .Property(e => e.Toy_Name)
                .IsUnicode(false);

            modelBuilder.Entity<Toy_Filter>()
                .Property(e => e.Remarks)
                .IsUnicode(false);
            modelBuilder.Entity<Toy_Filter>()
                .Property(e => e.Till_Date);
               
        }
    }
}
