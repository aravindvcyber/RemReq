﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ToyFilter.Models;

namespace ToyFilter.Controllers
{
    public class Toy_FilterController : Controller
    {
        private ToyFilter.Models.ToyFilter db = new ToyFilter.Models.ToyFilter();

        // GET: Toy_Filter
        public ActionResult Index()
        {
            return View(db.Toy_Filter.ToList());
        }

        // GET: Toy_Filter/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Toy_Filter toy_Filter = db.Toy_Filter.Find(id);
            if (toy_Filter == null)
            {
                return HttpNotFound();
            }
            return View(toy_Filter);
        }

        // GET: Toy_Filter/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Toy_Filter/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Toy_Id,Toy_Name,Remarks,Till_Date")] Toy_Filter toy_Filter)
        {
            if (ModelState.IsValid)
            {
                db.Toy_Filter.Add(toy_Filter);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(toy_Filter);
        }

        // GET: Toy_Filter/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Toy_Filter toy_Filter = db.Toy_Filter.Find(id);
            if (toy_Filter == null)
            {
                return HttpNotFound();
            }
            return View(toy_Filter);
        }

        // POST: Toy_Filter/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Toy_Id,Toy_Name,Remarks,Till_Date")] Toy_Filter toy_Filter)
        {
            if (ModelState.IsValid)
            {
                db.Entry(toy_Filter).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(toy_Filter);
        }

        // GET: Toy_Filter/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Toy_Filter toy_Filter = db.Toy_Filter.Find(id);
            if (toy_Filter == null)
            {
                return HttpNotFound();
            }
            return View(toy_Filter);
        }

        // POST: Toy_Filter/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            Toy_Filter toy_Filter = db.Toy_Filter.Find(id);
            db.Toy_Filter.Remove(toy_Filter);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
